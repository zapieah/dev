/** Automatically generated file. DO NOT MODIFY */
package com.bogon.test.threadpooltest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}