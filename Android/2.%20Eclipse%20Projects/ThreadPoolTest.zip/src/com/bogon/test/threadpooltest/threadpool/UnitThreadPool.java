package com.bogon.test.threadpooltest.threadpool;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import android.util.Log;

public class UnitThreadPool extends ThreadPoolExecutor{

    private static final String TAG = UnitThreadPool.class.getSimpleName();
    
    private CopyOnWriteArrayList<Runnable> mUnitThreadList;

    public UnitThreadPool(int corePoolSize, int maximumPoolSize,
            long keepAliveTime, TimeUnit unit, BlockingQueue<Runnable> workQueue) {
        super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue);
        Log.d(TAG, "UnitThreadPool");
        mUnitThreadList = new CopyOnWriteArrayList<Runnable>();
    }

    @Override
    protected void beforeExecute(Thread t, Runnable r) {
        // TODO Auto-generated method stub
        Log.d(TAG, "beforeExecute");
        mUnitThreadList.add(r);
        super.beforeExecute(t, r);
    }

    @Override
    protected void afterExecute(Runnable r, Throwable t) {
        // TODO Auto-generated method stub
        Log.d(TAG, "afterExecute");
        mUnitThreadList.remove(r);
        super.afterExecute(r, t);
    }
    
    public int getUnitThreadCount() {
        Log.d(TAG, "getUnitThreadCount");
        return mUnitThreadList.size();
    }
    
    public CopyOnWriteArrayList<Runnable> getUnitThreadList() {
        Log.d(TAG, "getUnitThreadList");
        return mUnitThreadList;
    }
}
