package com.bogon.test.threadpooltest.threadpool;

public interface UnitThreadCallback {
    void onThreadFinished(int UnitThreadId, Object o);
}
