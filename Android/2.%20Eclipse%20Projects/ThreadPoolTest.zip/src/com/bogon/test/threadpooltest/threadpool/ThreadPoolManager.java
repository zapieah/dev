package com.bogon.test.threadpooltest.threadpool;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import android.util.Log;

public class ThreadPoolManager {

    private static final String TAG = ThreadPoolManager.class.getSimpleName();
            
    private static final long KEEP_ALIVE_TIME = 13L;
    
    private static ThreadPoolManager sThreadPoolInstance;

    private BlockingQueue<Runnable> mThreadQueue = null;
    
    protected UnitThreadPool mTaskPool = null;
    
    private static final int PROCESS_COUNT = Runtime.getRuntime().availableProcessors();
            
    public static synchronized ThreadPoolManager getInstance() {
        Log.d(TAG, "getInstance");
        if (sThreadPoolInstance == null) {
            sThreadPoolInstance = new ThreadPoolManager();
        }
        return sThreadPoolInstance;
    }
    
    private ThreadPoolManager() {
        Log.d(TAG, "ThreadPoolManager");
        System.out.println("spec = " + (PROCESS_COUNT < 1 ? 1 : PROCESS_COUNT) + " " + (2 * PROCESS_COUNT) + " " +
                KEEP_ALIVE_TIME);
        mThreadQueue = new LinkedBlockingQueue<Runnable>();
        mTaskPool = new UnitThreadPool(PROCESS_COUNT < 1 ? 1 : PROCESS_COUNT, 2 * PROCESS_COUNT,
                KEEP_ALIVE_TIME, TimeUnit.SECONDS, mThreadQueue);

    }
    
    public void executeTask(UnitThread nt) {
        Log.d(TAG, "executeTask");
        execute(nt);
    }

    private void execute(UnitThread nt){ 
        Log.d(TAG, "execute");
        if (null != nt) {
            nt.setName("UnitThread" + nt.getUnitThreadId());
            mTaskPool.execute(nt);
        }
    }
    
    public void notifyUnitThread(int id) {
        Log.d(TAG, "notifyUnitThread");
        for (Runnable t : mTaskPool.getUnitThreadList()) {
            if (((UnitThread) t).getUnitThreadId() == id) {
                if (((UnitThread) t).getUnitThreadState() == UnitThread.STATE_WAITING)
                    ((UnitThread) t).notifyThread();
            }
        }
    }

    public boolean setMaxThreadNumber(int max) {
        Log.d(TAG, "setMaxThreadNumber");
        if ((max > 0) && (max <=2 * PROCESS_COUNT)) {
            mTaskPool.setMaximumPoolSize(max);
            return true;
        }
        else {
            Log.e(TAG, "max arg error");
            return false;
        }
    }
    
    public void allowThreadTimeOut(boolean bIsAllow) {
        Log.d(TAG, "allowThreadTimeOut");
        mTaskPool.allowCoreThreadTimeOut(bIsAllow);
    }
    
    public void shutdown() {
        Log.d(TAG, "shutdown");
//        for (Runnable t : mTaskPool.getUnitThreadList()) {
//            if (((UnitThread) t).getUnitThreadState() == UnitThread.STATE_WAITING)
//                ((UnitThread) t).notifyThread();
//        }
        shutdownAllTask();
    }

    private void shutdownAllTask() {
        Log.d(TAG, "shutdownAllTask");
        try {
            if (mTaskPool.getUnitThreadCount() == 0)
                mTaskPool.shutdownNow();
            else {
                //mTaskPool.shutdown();
                mTaskPool.shutdownNow();
                int count = 0;
                while (count <= 3) {
                    Thread.sleep(500);
                    if (mTaskPool.isTerminated())
                        break;
                    count++;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}