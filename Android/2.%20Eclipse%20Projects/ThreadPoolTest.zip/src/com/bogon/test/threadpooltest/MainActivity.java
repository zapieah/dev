package com.bogon.test.threadpooltest;

import com.bogon.test.threadpooltest.threadpool.ThreadPoolManager;
import com.bogon.test.threadpooltest.threadpool.UnitThread;
import com.bogon.test.threadpooltest.threadpool.UnitThreadCallback;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {

    private Button mButton;
    
    private int mNumber = 0;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mNumber = 0;
        mButton = (Button)this.findViewById(R.id.button);
        mButton.setOnClickListener(new OnClickListener() {
            
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                ThreadPoolManager.getInstance().notifyUnitThread(mNumber++);
            }
        });
        int i = 0; 
        for (i = 0; i < 50; i++) {
            makeThread(i);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
    public void makeThread(int id) {
        UnitThread nt = new UnitThread(id, mCallback);
        ThreadPoolManager.getInstance().executeTask(nt);
    }

    public void notifyThread(int id) {
        ThreadPoolManager.getInstance().notifyUnitThread(1);
    }

    private UnitThreadCallback mCallback = new UnitThreadCallback() {
        
        @Override
        public void onThreadFinished(int UnitThreadId, Object o) {
            // TODO Auto-generated method stub
            System.out.println("finished id = " + UnitThreadId);
        }
    };
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        // TODO Auto-generated method stub
        ThreadPoolManager.getInstance().shutdown();
        super.onDestroy();
    }
}
