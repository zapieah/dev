package com.bogon.test.threadpooltest.threadpool;

import android.util.Log;

public class UnitThread extends Thread{
    public static final String TAG = UnitThread.class.getSimpleName();

    public static final int STATE_NONE = 0;
    
    public static final int STATE_WAITING = 1;
    
    private int mId;
    
    private UnitThreadCallback mCallback; 
    
    private int mState;
    
    private Object lOCK_OBJECT;
    
    public UnitThread(int id, UnitThreadCallback callback) {
        Log.d(TAG, "UnitThread");
        mId = id;
        mCallback = callback;
        lOCK_OBJECT = new Object();
        setUnitThreadState(STATE_NONE);
    }
    
    public int getUnitThreadId() {
        Log.d(TAG, "getUnitThreadId");
        return mId;
    }
    
    public void waitThread() {
        Log.d(TAG, "waitThread");
        synchronized (UnitThread.this) {
            setUnitThreadState(STATE_WAITING);
            try {
                UnitThread.this.wait();
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }
    
    public void notifyThread() {
        Log.d(TAG, "notifyThread");
        synchronized (UnitThread.this) {
            if (mState == STATE_WAITING) {
                UnitThread.this.notify();
                setUnitThreadState(STATE_NONE);
            }
        }
    }
    
    public int getUnitThreadState() {
        Log.d(TAG, "getUnitThreadState");
        synchronized (lOCK_OBJECT) {
            return mState;
        }
    }
    
    private void setUnitThreadState(int state) {
        Log.d(TAG, "setUnitThreadState");
        synchronized (lOCK_OBJECT) {
            mState = state;
        }
    }
    
    @Override
    public void run() {
        // TODO Auto-generated method stub
        Log.d(TAG, "run + id = " + mId);
        waitThread();
        Log.d(TAG, "run - id = " + mId);
        mCallback.onThreadFinished(mId, new Object());
    }

}
